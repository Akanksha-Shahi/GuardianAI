interface AlertProps {
  type: 'high' | 'medium' | 'low';
  message: string;
  time: string;
  confidence: number;
}

export const Alert = ({ type, message, time, confidence }: AlertProps) => {
  const borderColor = {
    high: 'border-red-500',
    medium: 'border-yellow-500',
    low: 'border-green-500'
  }[type];

  return (
    <li className={`p-2 border-l-4 ${borderColor} bg-gray-50 rounded mb-2`}>
      <div className="text-sm">{message}</div>
      <div className="flex justify-between text-xs text-gray-500 mt-1">
        <span>{time}</span>
        <span>{confidence}% confidence</span>
      </div>
    </li>
  );
}