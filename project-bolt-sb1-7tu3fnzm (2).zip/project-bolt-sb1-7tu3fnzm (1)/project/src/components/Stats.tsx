interface StatProps {
  safe: number;
  flagged: number;
  blocked: number;
}

export const Stats = ({ safe, flagged, blocked }: StatProps) => {
  return (
    <div className="grid grid-cols-3 gap-2 mb-4">
      <div className="bg-gray-50 rounded p-2 text-center">
        <div className="text-lg font-bold text-green-500">{safe}</div>
        <div className="text-xs text-gray-600">Safe</div>
      </div>
      <div className="bg-gray-50 rounded p-2 text-center">
        <div className="text-lg font-bold text-yellow-500">{flagged}</div>
        <div className="text-xs text-gray-600">Flagged</div>
      </div>
      <div className="bg-gray-50 rounded p-2 text-center">
        <div className="text-lg font-bold text-red-500">{blocked}</div>
        <div className="text-xs text-gray-600">Blocked</div>
      </div>
    </div>
  );
}