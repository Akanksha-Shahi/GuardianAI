interface SliderProps {
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
}

export const Slider = ({ value, onChange, min, max }: SliderProps) => {
  return (
    <input
      type="range"
      min={min}
      max={max}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
    />
  );
};