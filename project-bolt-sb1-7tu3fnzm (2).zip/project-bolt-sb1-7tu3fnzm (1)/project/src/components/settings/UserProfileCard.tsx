interface UserProfileCardProps {
  profile: {
    id: string;
    label: string;
    description: string;
  };
  isActive: boolean;
  onClick: () => void;
}

export const UserProfileCard = ({ profile, isActive, onClick }: UserProfileCardProps) => {
  return (
    <div
      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
        isActive
          ? 'border-blue-500 bg-blue-50'
          : 'border-gray-200 hover:border-blue-200'
      }`}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div>
          <h4 className="font-medium text-lg mb-1">{profile.label}</h4>
          <p className="text-gray-600 text-sm">{profile.description}</p>
        </div>
        <div
          className={`w-4 h-4 rounded-full border-2 ${
            isActive
              ? 'border-blue-500 bg-blue-500'
              : 'border-gray-300'
          }`}
        />
      </div>
    </div>
  );
};