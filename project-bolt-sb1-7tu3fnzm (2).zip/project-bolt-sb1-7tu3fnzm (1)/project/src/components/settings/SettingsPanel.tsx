import { useState } from 'react';
import { Settings, Platform, UserProfile } from '../../types/settings';
import { Switch } from '../ui/Switch';
import { Slider } from '../ui/Slider';
import { Checkbox } from '../ui/Checkbox';
import { Tabs } from '../ui/Tabs';
import { UserProfileCard } from './UserProfileCard';
import { TextArea } from '../ui/TextArea';

interface SettingsPanelProps {
  settings: Settings;
  onSettingsChange: (settings: Settings) => void;
}

export const SettingsPanel = ({ settings, onSettingsChange }: SettingsPanelProps) => {
  const [activeTab, setActiveTab] = useState('basic');
  const [feedback, setFeedback] = useState('');

  const updateSettings = (updates: Partial<Settings>) => {
    onSettingsChange({ ...settings, ...updates });
  };

  const tabs = [
    { id: 'basic', label: '🔧 Basic Settings' },
    { id: 'filters', label: '📚 Filter Categories' },
    { id: 'ai', label: '🧠 AI Settings' },
    { id: 'platforms', label: '🌐 Platforms' },
    { id: 'blocking', label: '🚫 Block Method' },
    { id: 'keywords', label: '📝 Custom Keywords' },
    { id: 'profiles', label: '👤 User Profiles' },
    { id: 'reports', label: '📈 Reports & Logs' },
    { id: 'feedback', label: '📬 Feedback' },
    { id: 'ui', label: '🌙 UI Settings' },
    { id: 'privacy', label: '🔒 Privacy' },
  ];

  const platforms: { id: Platform; label: string; icon: string }[] = [
    { id: 'twitter', label: 'X (Twitter)', icon: '𝕏' },
    { id: 'facebook', label: 'Facebook', icon: '📘' },
    { id: 'instagram', label: 'Instagram', icon: '📸' },
    { id: 'reddit', label: 'Reddit', icon: '🔸' },
  ];

  const profiles: { id: UserProfile; label: string; description: string }[] = [
    {
      id: 'kid_safe',
      label: 'Kid Safe Mode',
      description: 'Maximum protection with strict content filtering suitable for children.',
    },
    {
      id: 'focus',
      label: 'Focus Mode',
      description: 'Block distracting content to help maintain productivity.',
    },
    {
      id: 'mental_wellness',
      label: 'Mental Wellness',
      description: 'Filter potentially triggering or harmful content for mental well-being.',
    },
    {
      id: 'custom',
      label: 'Custom',
      description: 'Personalized settings tailored to your preferences.',
    },
  ];

  const handleFeedbackSubmit = () => {
    // Handle feedback submission
    console.log('Feedback submitted:', feedback);
    setFeedback('');
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="bg-blue-600 p-4">
        <h2 className="text-xl font-semibold text-white">Settings</h2>
      </div>

      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      <div className="p-4">
        {activeTab === 'basic' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="font-medium">Enable Extension</label>
              <Switch
                checked={settings.isEnabled}
                onChange={(checked) => updateSettings({ isEnabled: checked })}
              />
            </div>

            <div>
              <label className="font-medium block mb-2">Sensitivity Level: {settings.sensitivity}</label>
              <Slider
                value={settings.sensitivity}
                onChange={(value) => updateSettings({ sensitivity: value })}
                min={0}
                max={100}
              />
              <div className="flex justify-between text-sm text-gray-500 mt-1">
                <span>Less Strict</span>
                <span>More Strict</span>
              </div>
            </div>

            <div>
              <label className="font-medium block mb-2">Content Types to Block</label>
              <div className="space-y-2">
                {['text', 'images', 'videos'].map((type) => (
                  <Checkbox
                    key={type}
                    label={type.charAt(0).toUpperCase() + type.slice(1)}
                    checked={settings.contentTypes.includes(type as any)}
                    onChange={(checked) => {
                      const types = checked
                        ? [...settings.contentTypes, type]
                        : settings.contentTypes.filter((t) => t !== type);
                      updateSettings({ contentTypes: types });
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'filters' && (
          <div className="space-y-4">
            <h3 className="font-medium mb-2">Filter Categories</h3>
            {[
              { id: 'hate_speech', label: 'Hate speech' },
              { id: 'harassment', label: 'Harassment/Bullying' },
              { id: 'profanity', label: 'Profanity' },
              { id: 'sexual', label: 'Sexual/explicit content' },
              { id: 'self_harm', label: 'Self-harm/suicidal ideation' },
              { id: 'misinformation', label: 'Misinformation/fake news' },
              { id: 'triggering', label: 'Triggering content' },
            ].map(({ id, label }) => (
              <Checkbox
                key={id}
                label={label}
                checked={settings.filterCategories.includes(id as FilterCategory)}
                onChange={(checked) => {
                  const categories = checked
                    ? [...settings.filterCategories, id as FilterCategory]
                    : settings.filterCategories.filter((c) => c !== id);
                  updateSettings({ filterCategories: categories });
                }}
              />
            ))}
          </div>
        )}

        {activeTab === 'ai' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="font-medium">Real-time Analysis</label>
              <Switch
                checked={settings.aiSettings.realTimeAnalysis}
                onChange={(checked) =>
                  updateSettings({
                    aiSettings: { ...settings.aiSettings, realTimeAnalysis: checked },
                  })
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <label className="font-medium">Share Anonymous Data</label>
              <Switch
                checked={settings.aiSettings.shareAnonymousData}
                onChange={(checked) =>
                  updateSettings({
                    aiSettings: { ...settings.aiSettings, shareAnonymousData: checked },
                  })
                }
              />
            </div>
          </div>
        )}

        {activeTab === 'platforms' && (
          <div className="space-y-4">
            <h3 className="font-medium mb-4">Select Platforms to Monitor</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {platforms.map(({ id, label, icon }) => (
                <div
                  key={id}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                    settings.platforms.includes(id)
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-200'
                  }`}
                  onClick={() => {
                    const newPlatforms = settings.platforms.includes(id)
                      ? settings.platforms.filter((p) => p !== id)
                      : [...settings.platforms, id];
                    updateSettings({ platforms: newPlatforms });
                  }}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{icon}</span>
                    <span className="font-medium">{label}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'profiles' && (
          <div className="space-y-4">
            <h3 className="font-medium mb-4">Choose Your Protection Profile</h3>
            <div className="grid grid-cols-1 gap-4">
              {profiles.map((profile) => (
                <UserProfileCard
                  key={profile.id}
                  profile={profile}
                  isActive={settings.activeProfile === profile.id}
                  onClick={() => updateSettings({ activeProfile: profile.id })}
                />
              ))}
            </div>
          </div>
        )}

        {activeTab === 'feedback' && (
          <div className="space-y-4">
            <h3 className="font-medium mb-4">Share Your Feedback</h3>
            <div>
              <TextArea
                value={feedback}
                onChange={setFeedback}
                placeholder="Tell us about your experience with GuardianAI..."
                rows={5}
              />
            </div>
            <div className="flex justify-end">
              <button
                onClick={handleFeedbackSubmit}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Submit Feedback
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};