interface SettingsProps {
  onSensitivityChange: (value: string) => void;
  onActionChange: (value: string) => void;
  sensitivity: string;
  action: string;
}

export const Settings = ({ 
  onSensitivityChange, 
  onActionChange,
  sensitivity,
  action 
}: SettingsProps) => {
  return (
    <div className="flex gap-2 mb-4">
      <div className="flex-1">
        <label htmlFor="sensitivity" className="block text-xs text-gray-700 mb-1">
          Sensitivity
        </label>
        <select
          id="sensitivity"
          value={sensitivity}
          onChange={(e) => onSensitivityChange(e.target.value)}
          className="w-full text-sm border rounded p-1.5"
        >
          <option>Low</option>
          <option>Medium</option>
          <option>High</option>
        </select>
      </div>
      <div className="flex-1">
        <label htmlFor="action" className="block text-xs text-gray-700 mb-1">
          Action
        </label>
        <select
          id="action"
          value={action}
          onChange={(e) => onActionChange(e.target.value)}
          className="w-full text-sm border rounded p-1.5"
        >
          <option>Block</option>
          <option>Flag</option>
          <option>Log only</option>
        </select>
      </div>
    </div>
  );
}