import { useState } from 'react';
import { format } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { AlertTriangle, CheckCircle, Flag, Ban } from 'lucide-react';

interface ToxicityReport {
  id: string;
  content: string;
  type: 'profanity' | 'threat' | 'insult' | 'hate_speech';
  confidence: number;
  timestamp: Date;
  action: 'blocked' | 'flagged' | 'hidden';
  url: string;
}

const mockReports: ToxicityReport[] = [
  {
    id: '1',
    content: 'This is a flagged message with inappropriate content',
    type: 'profanity',
    confidence: 85,
    timestamp: new Date(2024, 2, 15, 14, 30),
    action: 'flagged',
    url: 'https://example.com/post/1'
  },
  {
    id: '2',
    content: 'This message contains threatening language',
    type: 'threat',
    confidence: 92,
    timestamp: new Date(2024, 2, 15, 15, 45),
    action: 'blocked',
    url: 'https://example.com/post/2'
  },
  {
    id: '3',
    content: 'Message with insulting content',
    type: 'insult',
    confidence: 78,
    timestamp: new Date(2024, 2, 15, 16, 20),
    action: 'hidden',
    url: 'https://example.com/post/3'
  }
];

const analyticsData = [
  { name: 'Profanity', count: 15 },
  { name: 'Threats', count: 8 },
  { name: 'Insults', count: 12 },
  { name: 'Hate Speech', count: 5 }
];

export const ReportView = () => {
  const [selectedReport, setSelectedReport] = useState<ToxicityReport | null>(null);

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'blocked':
        return <Ban className="w-5 h-5 text-red-500" />;
      case 'flagged':
        return <Flag className="w-5 h-5 text-yellow-500" />;
      case 'hidden':
        return <AlertTriangle className="w-5 h-5 text-orange-500" />;
      default:
        return null;
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'text-red-500';
    if (confidence >= 70) return 'text-yellow-500';
    return 'text-green-500';
  };

  return (
    <div className="w-full max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="bg-blue-600 p-4">
        <h2 className="text-xl font-semibold text-white">Content Analysis Report</h2>
      </div>

      <div className="p-6">
        {/* Analytics Section */}
        <div className="mb-8">
          <h3 className="text-lg font-medium mb-4">Toxicity Distribution</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detailed Reports */}
        <div>
          <h3 className="text-lg font-medium mb-4">Recent Detections</h3>
          <div className="space-y-4">
            {mockReports.map((report) => (
              <div
                key={report.id}
                className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() => setSelectedReport(report)}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      {getActionIcon(report.action)}
                      <span className="font-medium capitalize">{report.type.replace('_', ' ')}</span>
                    </div>
                    <p className="text-gray-600 mb-2">{report.content}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>{format(report.timestamp, 'MMM d, yyyy HH:mm')}</span>
                      <span className={getConfidenceColor(report.confidence)}>
                        {report.confidence}% confidence
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      className="text-gray-500 hover:text-green-500 transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle marking as safe
                      }}
                    >
                      <CheckCircle className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Report Details Modal */}
        {selectedReport && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg max-w-2xl w-full p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-medium">Detection Details</h3>
                <button
                  onClick={() => setSelectedReport(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="font-medium block mb-1">Content</label>
                  <p className="text-gray-600">{selectedReport.content}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="font-medium block mb-1">Type</label>
                    <p className="capitalize">{selectedReport.type.replace('_', ' ')}</p>
                  </div>
                  <div>
                    <label className="font-medium block mb-1">Action Taken</label>
                    <p className="capitalize">{selectedReport.action}</p>
                  </div>
                  <div>
                    <label className="font-medium block mb-1">Confidence</label>
                    <p className={getConfidenceColor(selectedReport.confidence)}>
                      {selectedReport.confidence}%
                    </p>
                  </div>
                  <div>
                    <label className="font-medium block mb-1">Detected At</label>
                    <p>{format(selectedReport.timestamp, 'PPpp')}</p>
                  </div>
                </div>

                <div>
                  <label className="font-medium block mb-1">Source URL</label>
                  <a
                    href={selectedReport.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline"
                  >
                    {selectedReport.url}
                  </a>
                </div>

                <div className="flex justify-end gap-3 mt-6">
                  <button
                    onClick={() => setSelectedReport(null)}
                    className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                  >
                    Close
                  </button>
                  <button
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                    onClick={() => {
                      // Handle marking as safe
                      setSelectedReport(null);
                    }}
                  >
                    Mark as Safe
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};