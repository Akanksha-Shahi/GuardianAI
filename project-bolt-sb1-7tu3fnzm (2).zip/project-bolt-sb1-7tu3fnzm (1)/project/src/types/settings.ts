export type ContentType = 'text' | 'images' | 'videos';
export type FilterCategory = 'hate_speech' | 'harassment' | 'profanity' | 'sexual' | 'self_harm' | 'misinformation' | 'triggering';
export type Platform = 'twitter' | 'reddit' | 'youtube' | 'facebook' | 'instagram' | 'custom';
export type BlockMethod = 'hide' | 'blur' | 'replace' | 'click_to_reveal';
export type UserProfile = 'kid_safe' | 'focus' | 'mental_wellness' | 'custom';
export type Theme = 'light' | 'dark' | 'system';

export interface Settings {
  isEnabled: boolean;
  sensitivity: number;
  contentTypes: ContentType[];
  filterCategories: FilterCategory[];
  aiSettings: {
    realTimeAnalysis: boolean;
    shareAnonymousData: boolean;
  };
  platforms: Platform[];
  customDomains: {
    whitelist: string[];
    blacklist: string[];
  };
  blockMethod: BlockMethod;
  customKeywords: string[];
  activeProfile: UserProfile;
  logs: {
    enabled: boolean;
    retentionDays: number;
  };
  feedback: {
    enableReporting: boolean;
    collectFeedback: boolean;
  };
  theme: Theme;
  contentWarnings: 'minimal' | 'detailed';
  privacy: {
    storeData: boolean;
    dataRetentionDays: number;
  };
}