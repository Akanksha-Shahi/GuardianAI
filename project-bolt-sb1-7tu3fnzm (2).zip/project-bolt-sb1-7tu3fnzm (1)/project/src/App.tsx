import { useState } from 'react';
import { Logo } from './components/Logo';
import { Stats } from './components/Stats';
import { Alert } from './components/Alert';
import { Settings } from './components/Settings';
import { SettingsPanel } from './components/settings/SettingsPanel';
import { ReportView } from './components/report/ReportView';
import { Settings as SettingsType } from './types/settings';

interface Alert {
  type: 'high' | 'medium' | 'low';
  message: string;
  time: string;
  confidence: number;
}

function App() {
  const [showSettings, setShowSettings] = useState(false);
  const [showReport, setShowReport] = useState(false);

  const [settings, setSettings] = useState<SettingsType>({
    isEnabled: true,
    sensitivity: 50,
    contentTypes: ['text', 'images', 'videos'],
    filterCategories: ['hate_speech', 'harassment', 'profanity'],
    aiSettings: {
      realTimeAnalysis: true,
      shareAnonymousData: false,
    },
    platforms: ['twitter', 'reddit', 'youtube', 'facebook', 'instagram'],
    customDomains: {
      whitelist: [],
      blacklist: [],
    },
    blockMethod: 'blur',
    customKeywords: [],
    activeProfile: 'custom',
    logs: {
      enabled: true,
      retentionDays: 30,
    },
    feedback: {
      enableReporting: true,
      collectFeedback: true,
    },
    theme: 'light',
    contentWarnings: 'detailed',
    privacy: {
      storeData: true,
      dataRetentionDays: 30,
    },
  });

  const [sensitivity, setSensitivity] = useState('Medium');
  const [action, setAction] = useState('Flag');
  const [stats, setStats] = useState({ safe: 24, flagged: 3, blocked: 1 });

  const [alerts] = useState<Alert[]>([
    {
      type: 'high',
      message: 'Harmful content detected in post',
      time: 'Just now',
      confidence: 92
    },
    {
      type: 'medium',
      message: 'Potential inappropriate content',
      time: '10 min ago',
      confidence: 76
    },
    {
      type: 'low',
      message: 'Mild profanity detected',
      time: '25 min ago',
      confidence: 62
    }
  ]);

  // Show settings panel
  if (showSettings) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden p-4">
          <button
            className="mb-4 px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
            onClick={() => setShowSettings(false)}
          >
            ← Back
          </button>
          <SettingsPanel settings={settings} onSettingsChange={setSettings} />
        </div>
      </div>
    );
  }

  // Show report view
  if (showReport) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden p-4">
          <button
            className="mb-4 px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
            onClick={() => setShowReport(false)}
          >
            ← Back
          </button>
          <ReportView />
        </div>
      </div>
    );
  }

  // Main dashboard view
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="bg-blue-600 p-4 flex items-center gap-3">
          <Logo />
          <h1 className="text-xl font-semibold text-white">GuardianAI</h1>
        </div>

        <div className="p-4">
          <div className="flex items-center gap-2 p-2 bg-blue-50 rounded mb-4">
            <div className={`w-3 h-3 rounded-full ${settings.isEnabled ? 'bg-green-500' : 'bg-red-500'}`} />
            <div className="font-medium text-blue-900">
              {settings.isEnabled ? 'Protection Active' : 'Protection Inactive'}
            </div>
          </div>

          <Stats {...stats} />

          <div className="mb-4">
            <h2 className="text-sm font-semibold text-gray-700 mb-2">Recent Alerts</h2>
            <ul className="max-h-40 overflow-y-auto">
              {alerts.map((alert, index) => (
                <Alert key={index} {...alert} />
              ))}
            </ul>
          </div>

          <Settings
            sensitivity={sensitivity}
            action={action}
            onSensitivityChange={setSensitivity}
            onActionChange={setAction}
          />

          <div className="flex gap-2 mt-4">
            <button
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded font-medium hover:bg-gray-300 transition-colors"
              onClick={() => {
                window.open('report.html', '_blank', 'width=600,height=600');
              }}
              
            >
              Settings
            </button>
            <button
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded font-medium hover:bg-blue-700 transition-colors"
              onClick={() => {
                window.open('report.html', '_blank', 'width=600,height=600');
              }}
              
            >
              View Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
